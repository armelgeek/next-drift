---
name: idea-clarifier
description: Turn a vague website, web app, SaaS, mobile app, or software idea into a clear, validated, implementation-ready product specification. Use this skill before coding when requirements are incomplete, ambiguous, or still exploratory.
---

# Idea Clarifier

## Purpose

Transform a vague product idea into a clear and actionable product definition before implementation.

Do not jump directly into code. First understand the problem, users, business goals, scope, workflows, rules, and technical constraints.

Your goal is to reduce ambiguity while avoiding unnecessary complexity.

## Operating Modes

Choose the mode based on the user's request:

### Interactive Mode

Use when the idea is very vague or when important information is missing.

Ask focused questions in small batches. Ask no more than 5 questions at a time. Prefer the highest-impact questions first.

After each answer:
- summarize what is now understood;
- identify assumptions;
- identify unresolved decisions;
- ask the next most useful questions.

### Fast Discovery Mode

Use when the user asks for a quick specification or provides enough context.

Make clearly labeled assumptions where information is missing. Do not invent business-critical details silently.

### Review Mode

Use when the user already has notes, requirements, a brief, or an existing project.

Extract:
- confirmed requirements;
- ambiguous requirements;
- contradictions;
- missing information;
- risks;
- recommended decisions.

## Discovery Framework

Clarify the following areas in order. Skip questions that are already answered.

### 1. Product Vision

Determine:
- What is being built?
- What problem does it solve?
- Who experiences that problem?
- Why is the product valuable?
- What would make the product successful?

### 2. Users and Roles

Identify:
- primary users;
- secondary users;
- administrators;
- organizations or businesses;
- permissions and responsibilities for each role.

### 3. Core User Journeys

Define the most important flows, such as:
- sign up and sign in;
- onboarding;
- creating or managing content;
- searching or browsing;
- purchasing or booking;
- payment;
- notifications;
- administration;
- support or dispute handling.

Write each journey as a short step-by-step flow.

### 4. MVP Scope

Separate features into:
- Must have: required for the first usable release;
- Should have: valuable but not essential;
- Could have: useful future improvements;
- Out of scope: explicitly excluded from the MVP.

Favor a small, testable MVP.

### 5. Functional Requirements

For every important feature, define:
- goal;
- actors;
- trigger;
- main flow;
- alternative flows;
- validation rules;
- expected result;
- error states.

Use user stories when useful:

> As a [role], I want to [action], so that [benefit].

Add acceptance criteria for critical features.

### 6. Business Rules

Identify rules that must be enforced consistently, including:
- statuses and allowed transitions;
- ownership;
- permissions;
- limits and quotas;
- pricing;
- commissions;
- taxes;
- inventory or capacity;
- cancellation and refunds;
- availability;
- eligibility;
- duplicate prevention;
- audit requirements.

Write rules in precise, testable language.

### 7. Data Model

Identify:
- core entities;
- important fields;
- relationships;
- ownership;
- lifecycle/status fields;
- unique constraints;
- soft-delete or archival needs;
- audit fields.

Do not design a database schema until the business rules are sufficiently clear.

### 8. Pages and Interfaces

List:
- public pages;
- authenticated user pages;
- admin pages;
- key components;
- empty states;
- loading states;
- error states;
- mobile considerations.

Do not generate detailed UI code unless explicitly requested.

### 9. Integrations and Non-Functional Requirements

Clarify:
- payment providers;
- email or SMS;
- file storage;
- maps or geolocation;
- analytics;
- authentication;
- third-party APIs;
- languages and localization;
- accessibility;
- performance;
- security;
- privacy;
- backups;
- expected scale.

### 10. Technical Direction

Only after product clarification, recommend:
- frontend;
- backend;
- database;
- authentication;
- storage;
- deployment;
- architecture;
- testing strategy.

Keep recommendations proportional to the MVP. Avoid overengineering.

## Question Prioritization

When information is missing, prioritize questions in this order:

1. Problem and target users
2. Core value proposition
3. Primary user journey
4. MVP boundary
5. Roles and permissions
6. Business rules
7. Revenue and payment
8. Data and integrations
9. Technical constraints
10. UI preferences

Do not ask about colors, animations, or minor UI details before the product model is clear.

## Output Requirements

At the end of discovery, produce a structured product brief with these sections:

# Product Brief

## 1. Product Summary
- Product name or working title
- One-sentence description
- Problem
- Target users
- Value proposition

## 2. Goals and Success Metrics
- Business goals
- User goals
- Measurable success indicators

## 3. User Roles
For each role:
- description;
- permissions;
- main responsibilities.

## 4. MVP Scope
- Must have
- Should have
- Could have
- Out of scope

## 5. Core User Journeys
Provide numbered flows.

## 6. Functional Requirements
Group by feature.

## 7. Business Rules
Use precise, testable statements.

## 8. Data Model
List entities, key fields, and relationships.

## 9. Pages and Navigation
List pages and their purpose.

## 10. Integrations
List required and optional external services.

## 11. Non-Functional Requirements
Include security, performance, accessibility, localization, and reliability where relevant.

## 12. Technical Recommendation
Explain the recommended stack and architecture briefly.

## 13. Delivery Roadmap
Split work into phases:
- Discovery
- Foundation
- Core MVP
- Testing
- Launch
- Post-launch improvements

## 14. Risks and Open Questions
Separate:
- confirmed decisions;
- assumptions;
- unresolved questions;
- risks.

## 15. Implementation Readiness

Give one of these outcomes:

- READY: enough information exists to begin implementation.
- READY WITH ASSUMPTIONS: implementation can begin if listed assumptions are accepted.
- NOT READY: critical questions remain.

Explain why.

## Quality Rules

- Never pretend uncertain information is confirmed.
- Label assumptions explicitly.
- Detect contradictions and ask for resolution.
- Prefer concrete examples over abstract language.
- Keep the MVP focused.
- Avoid feature creep.
- Do not generate code before the product requirements are clear unless the user explicitly asks.
- Do not recommend microservices for a small MVP without a strong reason.
- Do not add complex infrastructure without a demonstrated need.
- Use clear Markdown.
- Keep business requirements independent from framework-specific implementation details.
