# Idea Clarifier — Claude Code Skill

A reusable Claude Code skill that turns vague website, SaaS, web app, mobile app, or software ideas into clear, implementation-ready product specifications.

## Installation

Copy the `idea-clarifier` folder into one of these locations:

### Project-level skill

```text
your-project/
└── .claude/
    └── skills/
        └── idea-clarifier/
            └── SKILL.md
```

### Personal skill

```text
~/.claude/
└── skills/
    └── idea-clarifier/
        └── SKILL.md
```

## Usage

Start Claude Code in your project, then ask:

```text
Use the idea-clarifier skill.

I want to build a platform where event organizers can sell tickets.
The idea is still vague. Help me define the product before writing code.
```

You can also request a specific mode:

```text
Use idea-clarifier in interactive mode.
Ask me the most important questions first.
```

```text
Use idea-clarifier in fast discovery mode.
Make explicit assumptions and generate a complete MVP specification.
```

```text
Use idea-clarifier in review mode.
Analyze these requirements, find ambiguities and contradictions, then propose a clearer specification.
```

## What it produces

- Product vision
- Target users and roles
- MVP scope
- User stories
- Core user journeys
- Functional requirements
- Business rules
- Data model
- Pages and navigation
- Integrations
- Non-functional requirements
- Technical recommendations
- Delivery roadmap
- Risks and open questions
- Implementation readiness status

## Recommended workflow

```text
Vague idea
   ↓
Idea Clarifier
   ↓
Product Brief
   ↓
Architecture and database design
   ↓
Implementation plan
   ↓
Development
```
